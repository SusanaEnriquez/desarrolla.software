import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'examen',
  templateUrl: './examen.html',
  styleUrls: ['./examen.css']
})
export class ExamenComponent implements OnInit {

  calificacion: Number;
  nombre: String;
  preguntas: Array<String>;

  examenes = [
    {
      nombreAlumno: 'Susy',
      calificacion: 9
    },
    {
      nombreAlumno: 'Mariana',
      calificacion: 10
    },
    {
      nombreAlumno: 'Leticia',
      calificacion: 8
    }
  ]

  constructor() { }

  ngOnInit(): void {
  }

}
